package com.example.myhomework;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
/*This program is my Tip calculator.
* and last homework*/
public class Activity3 extends AppCompatActivity implements View.OnClickListener {
    double priceI;
    double total,tip;
    double otherI;
    EditText price;
    EditText other;
    Button btnOk;
    Button btn15;
    Button btn20;
    Button btnOther;
    private Context context;
    private int duration = Toast.LENGTH_SHORT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        context = getApplicationContext();
        price = (EditText) findViewById(R.id.editText);
        btnOk = (Button) findViewById(R.id.okbtn);
        btn15 = (Button) findViewById(R.id.radioButton);
        btn20 = (Button) findViewById(R.id.radioButton2);
        btnOther = (Button) findViewById(R.id.radioButton3);
        other = (EditText) findViewById(R.id.editText2);

        price.setOnClickListener(this);
        btnOk.setOnClickListener(this);
        btn15.setOnClickListener(this);
        btn20.setOnClickListener(this);
        btnOther.setOnClickListener(this);
        other.setOnClickListener(this);
        price.setText("Total Amount");
    }
    @Override
    public void onClick(View v){ //Event handler : About each radiobutton. and I used getId() method.
        if(v.getId()==btnOk.getId()){
            if(total<1){
                Toast.makeText(getApplicationContext(),"your number is null",duration).show();
            }
            Toast.makeText(getApplicationContext(), "Total = " + total + "\nTip = " + tip, duration).show();
        }
        /*I used number edittext. You can confirm to Xml that like inputtype=number.
         * so I don't need exception case like negative number. */
        else if(v.getId()==btn15.getId()){
            String priceS = price.getText().toString();
            priceI = (double) Integer.parseInt(priceS);
            tip = (double) priceI * 0.15;
            total = (double) priceI + ((double) priceI * 0.15);
        }
        else if(v.getId()==btn20.getId()){
            String priceS = price.getText().toString();
            priceI = (double) Integer.parseInt(priceS);
            tip = (double) priceI * 0.20;
            total = (double) priceI + ((double) priceI * 0.20);
        }
        else if((v.getId()==btnOther.getId())&&other.getText()!=null){
            String priceS = price.getText().toString();
            String otherS = other.getText().toString();
            priceI = (double) Integer.parseInt(priceS);
            otherI = (double) Integer.parseInt(otherS) / 100;
            tip = (double) priceI * (double) otherI;
            total = (double) priceI + ((double) priceI * otherI);
        }
    }
}
