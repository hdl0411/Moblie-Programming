package com.example.myhomework;

import android.app.Activity;
import android.app.ListActivity;
import android.content.*;
import android.content.Intent;
import android.media.Image;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.view.*;
import android.widget.*;

import java.util.*;
/*This is Veiw of list about HomeWork*/
public class HWListActivity extends ListActivity {
    String[] values = new String[]{"My Table", "My Tip", "My Calculator","Change Password"};
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        int[] imgid = new int[]{R.drawable.time,R.drawable.money,R.drawable.cal,R.drawable.ic_launcher};
        imglist adapter = new imglist(this, values,imgid);
        setListAdapter(adapter);
    }
    public void onListItemClick(ListView parent, View v, int position, long id) {

        // 각 if문에서 설명 activity를 호출
        if (values[position] == "My Table") {
            startActivity(new Intent(HWListActivity.this, Activity2explain.class));
        }
        if (values[position] == "My Tip") {
            startActivity(new Intent(HWListActivity.this, Activity3explain.class));
        }
        if (values[position] == "My Calculator") {
            startActivity(new Intent(HWListActivity.this, Activity4explain.class));
        }
        if(values[position]=="Change Password"){
            startActivity(new Intent(HWListActivity.this,Activity5.class));
        }
    }



}




