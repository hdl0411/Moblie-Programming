package com.example.myhomework;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
/*This section is image list */
public class imglist extends ArrayAdapter<String> {
    private final Context context;
    private final String[] values;
    private final int[] num;

    public imglist(Context context, String[] values,int[] num) {
        super(context, R.layout.activity_imglist, values);
        this.context = context;
        this.values = values;
        this.num = num;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity_imglist, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
        textView.setText(values[position]);
        String s = values[position];
        //get each image
        if (s.startsWith("My Table")) {
            imageView.setImageResource(R.drawable.time);
        } else if (s.startsWith("My Tip")) {
            imageView.setImageResource(R.drawable.money);
        } else if (s.startsWith("My Calculator")) {
            imageView.setImageResource(R.drawable.cal);
        } else if (s.startsWith("Change password")){
            imageView.setImageResource(R.drawable.ic_launcher);
        }
        return rowView;
    }
}