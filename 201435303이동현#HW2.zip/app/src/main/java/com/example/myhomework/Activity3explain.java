package com.example.myhomework;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;

public class Activity3explain extends AppCompatActivity {
    /*This activity is Explain activity about Tip calculator*/
    Button start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity3explain);
        start = (Button) findViewById(R.id.okay);
    }
    public void onClick(View v){
        startActivity(new Intent(Activity3explain.this, Activity3.class));
        //start Tip calculator
        finish();
    }
}
