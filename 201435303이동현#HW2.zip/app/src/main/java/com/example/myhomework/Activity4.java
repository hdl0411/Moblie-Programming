package com.example.myhomework;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myhomework.HWListActivity;
import com.example.myhomework.R;
/*This program is my calculator.
* and last homework*/
public class Activity4 extends Activity {
    private Button button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,button12,button13,button14,button15,button16;
    private TextView text;
    private EditText edit;
    private double a;
    private int where=0;
    Intent in =  new Intent(this,HWListActivity.class);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_4);
        //all buttons make.
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);
        button4 = (Button)findViewById(R.id.button4);
        button5 = (Button)findViewById(R.id.button5);
        button6 = (Button)findViewById(R.id.button6);
        button7 = (Button)findViewById(R.id.button7);
        button8 = (Button)findViewById(R.id.button8);
        button9 = (Button)findViewById(R.id.button9);
        button10 = (Button)findViewById(R.id.button10);
        button11 = (Button)findViewById(R.id.button11);
        button12 = (Button)findViewById(R.id.button12);
        button13 = (Button)findViewById(R.id.button13);
        button14 = (Button)findViewById(R.id.button14);
        button15 = (Button)findViewById(R.id.button15);
        button16 = (Button)findViewById(R.id.button16);
        text = (TextView)findViewById(R.id.e1);
        edit = (EditText)findViewById(R.id.e1);


        OnClickListener cl = new OnClickListener(){
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(v==button1){
                    edit.setText(edit.getText().toString()+1);
                }
                else if(v==button2){
                    edit.setText(edit.getText().toString()+2);
                }
                else if(v==button3){
                    edit.setText(edit.getText().toString()+3);
                }
                else if(v==button4){
                    // +  section
                    a = Integer.valueOf(edit.getText().toString().trim());
                    edit.setText("");
                    where =1;
                }

                else if(v==button5){
                    edit.setText(edit.getText().toString()+4);
                }

                else if(v==button6){
                    edit.setText(edit.getText().toString()+5);
                }
                else if(v==button7){
                    edit.setText(edit.getText().toString()+6);
                }
                else if(v==button8){
                    //- section
                    a = Integer.valueOf(edit.getText().toString().trim());
                    edit.setText("");
                    where =2;
                }
                else if(v==button9){
                    edit.setText(edit.getText().toString()+7);
                }
                else if(v==button10){
                    edit.setText(edit.getText().toString()+8);
                }
                else if(v==button11){
                    edit.setText(edit.getText().toString()+9);
                }
                else if(v==button12){
                    //* section
                    a = Integer.valueOf(edit.getText().toString().trim());
                    edit.setText("");
                    where =3;
                }
                else if(v==button13){
                    edit.setText(edit.getText().toString()+0);
                }
                else if(v==button14){
                    //= section
                    if(where==1){
                        a = a + Integer.valueOf(edit.getText().toString().trim());
                        edit.setText(Double.toString(a));
                    }
                    else if(where==2){
                        a = a - Integer.valueOf(edit.getText().toString().trim());
                        edit.setText(Double.toString(a));
                    }
                    else if(where==3){
                        a = a * Integer.valueOf(edit.getText().toString().trim());
                        edit.setText(Double.toString(a));
                    }
                    else if(where==4){
                        a = a / Integer.valueOf(edit.getText().toString().trim());
                        edit.setText(Double.toString(a));
                    }

                    in.putExtra("vresult",a);
                    setResult(Activity.RESULT_OK, in);
                    finish();
                }
                else if(v==button15){
                    //C section
                    edit.setText("");
                }
                else if(v==button16){
                    // /
                    a = Integer.valueOf(edit.getText().toString().trim());
                    edit.setText("");
                    where =4;
                }
            }
        };
        button1.setOnClickListener(cl);
        button2.setOnClickListener(cl);
        button3.setOnClickListener(cl);
        button4.setOnClickListener(cl);
        button5.setOnClickListener(cl);
        button6.setOnClickListener(cl);
        button7.setOnClickListener(cl);
        button8.setOnClickListener(cl);
        button9.setOnClickListener(cl);
        button10.setOnClickListener(cl);
        button11.setOnClickListener(cl);
        button12.setOnClickListener(cl);
        button13.setOnClickListener(cl);
        button14.setOnClickListener(cl);
        button15.setOnClickListener(cl);
        button16.setOnClickListener(cl);
    }
}
