package com.example.myhomework;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;

public class Activity2explain extends AppCompatActivity {
/*This activity is Explain activity about time tabel*/
    Button start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2explain);
        start = (Button) findViewById(R.id.okay);
    }
    public void startact(View v){
        startActivity(new Intent(Activity2explain.this, Activity2.class));
        //start time table activity
        finish();
    }
}
