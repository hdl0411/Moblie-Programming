package com.example.myhomework;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
/*This activity is change password*/
public class Activity5 extends AppCompatActivity {
    SharedPreferences dataPassword;
    EditText t;
    Button ok,cancle;
    String pass;
    SharedPreferences.Editor edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);

        t=(EditText) findViewById(R.id.pass);
        ok=(Button) findViewById(R.id.ok);
        cancle=(Button)findViewById(R.id.cancle);
    }
    public void onClick(View v)
    {
        //take your new password about string
        pass = t.getText().toString();
        newPass();
        if(v.getId()==cancle.getId())
            finish();
    }
    public void newPass()
    {
        /*This section is getSharedPreferences and new pass saved*/
        dataPassword = getSharedPreferences("Password datas", MODE_PRIVATE);
        edit = dataPassword.edit();
        edit.putString("password", pass);
        edit.commit();
        Toast.makeText(getApplicationContext(),"your password changed",Toast.LENGTH_SHORT).show();
        finish();
    }
}
