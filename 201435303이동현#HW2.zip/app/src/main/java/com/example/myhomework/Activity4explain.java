package com.example.myhomework;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Activity4explain extends AppCompatActivity {
    /*This activity is Explain activity about  calculator*/
    Button start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4explain);
        start = (Button) findViewById(R.id.okay);
    }
    public void onClick(View v){
        Intent myIntent = new Intent(Activity4explain.this, Activity4.class);
        startActivityForResult(myIntent, 101);
        //start calculator and pass the code and received result
    }
    @Override
    //this section is about return result and OK_code
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if ((requestCode == 101) && (resultCode == Activity.RESULT_OK)) {
                Bundle myResults = data.getExtras();
                Double vresult = myResults.getDouble("vresult");
                Toast.makeText(getApplicationContext(), "" + vresult, Toast.LENGTH_SHORT).show();
                finish();
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Occured error!!!", Toast.LENGTH_SHORT).show();
        }
    }
}
