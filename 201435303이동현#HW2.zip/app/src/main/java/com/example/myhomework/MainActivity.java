package com.example.myhomework;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText t1, t2, t3, t4;
    SharedPreferences dataPassword;
    SharedPreferences.Editor edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences();
        inputPass();
    }

    public void inputPass() {
        /* In here, all about password.
        * Points are requestFocus, Watcher
        * And sharedPreferences */
        t1 = (EditText) findViewById(R.id.p1);
        t2 = (EditText) findViewById(R.id.p2);
        t3 = (EditText) findViewById(R.id.p3);
        t4 = (EditText) findViewById(R.id.p4);

        t1.addTextChangedListener(new TextWatcher() {
            /* This is about t1.
            * 't1' is first password text*/
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!t1.getText().toString().equals("")) {
                    //if t1 is not null, focused next password text(t2)
                    t2.requestFocus();
                   // t2.setCursorVisible(true);
                }
            }// after input 입력 후

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        t2.addTextChangedListener(new TextWatcher() {
            /* This is about t2.
            * 't2' is second password text*/
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!t2.getText().toString().equals("")) {
                    //if t2 is not null, focused next password text(t3)
                    t3.requestFocus();
                    t3.setCursorVisible(true);
                }
            }// after input

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        t3.addTextChangedListener(new TextWatcher() {
            /* This is about t3.
             * 't3' is third password text*/
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!t3.getText().toString().equals("")) {
                    //if t3 is not null, focused next password text(t4)
                    t4.requestFocus();
                    t4.setCursorVisible(true);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        t4.addTextChangedListener(new TextWatcher() {
            /* This is about t4.
             * 't4' is fourth password text*/
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!t4.getText().toString().equals("")) {
                    /*This is about sharedPreference
                    * and if your input correct passowrd then startActivity HWListActivity
                    * but your input wrong password then toast the message like "Wrong !!!"
                    * */
                    dataPassword = getSharedPreferences("Password datas", MODE_PRIVATE);
                    edit = dataPassword.edit();
                    String str = t1.getText().toString() + t2.getText().toString() + t3.getText().toString() + t4.getText().toString();

                    if (str.equals(dataPassword.getString("password", "0000"))) {
                        startActivity(new Intent(MainActivity.this, HWListActivity.class));
                        //initialized t1~t4 and refocused t1
                        t1.setText("");
                        t2.setText("");
                        t3.setText("");
                        t4.setText("");


                        t1.requestFocus();
                        t1.setCursorVisible(true);
                    } else {
                        //This section is your input password is wrong
                        t1.setText("");
                        t2.setText("");
                        t3.setText("");
                        t4.setText("");

                        t1.requestFocus();
                        t1.setCursorVisible(true);
                        Toast.makeText(getApplicationContext(), "Wrong!!", Toast.LENGTH_SHORT).show();


                        InputMethodManager hideKeyboard = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                        hideKeyboard.hideSoftInputFromWindow(t4.getWindowToken(), 0);
                    }
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

    }

    public void sharedPreferences() {
        dataPassword = getSharedPreferences("Password datas", MODE_PRIVATE);
        edit = dataPassword.edit();
        // your first password is 0000
        edit.putString("password", "0000");
        edit.commit();
    }
}