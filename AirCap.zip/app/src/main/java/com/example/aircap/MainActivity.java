package com.example.aircap;

import android.os.Bundle;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.GridLayout;

public class MainActivity extends AppCompatActivity {

    MyView[] view = new MyView[100];
    GridLayout layout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout = (GridLayout)findViewById(R.id.layout);
        layout.setColumnCount(8); // 가로로 8개를 놓겠다 즉, 세로로 8줄이 된다.
        Resources res = getResources();
        Bitmap perfect = BitmapFactory.decodeResource(res,R.drawable.bubb); //"bubb" 그림을 비트맵으로 뿌려주겠다.
        for(int i=0; i<100; i++) {
            view[i] = new MyView(this);
            view[i].setLayoutParams(new AbsListView.LayoutParams(perfect.getWidth(), perfect.getHeight()));
            layout.addView(view[i]); //한개의 bubble을 gridlayout에 보여주겠다. (어레이 이용) for문을 이용한 꽉차게 분배.
        }
    }
    protected class MyView extends View {
        Resources res;
        Bitmap normal,click;
        Bitmap Bubble;

        public MyView(Context context) {
            super(context);
            res = getResources();
            normal = BitmapFactory.decodeResource(res,R.drawable.bubb); // 기본 버블
            click = BitmapFactory.decodeResource(res,R.drawable.unbub); // 터진 버블
            Bubble = normal;
        }
        public void onDraw(Canvas canvas) {
            Paint pnt = new Paint();
            canvas.drawColor(Color.WHITE); // 쉽게말하면 조그만 바탕
            canvas.drawBitmap(Bubble,0,0,pnt); // canvas에 해당 bitmap을 draw해줌
        }
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_UP: //터치를 했다가 손을 떼면 "action"을 show에 어사인시켜 발동
                    Bubble = click;
                    break;
            }
            invalidate();
            return true;
        }
    }
}
